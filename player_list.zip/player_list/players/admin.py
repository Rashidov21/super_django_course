from django.contrib import admin
from .models import Club,Career,Tournament,Player
# Register your models here.

admin.site.register(Club)
admin.site.register(Career)
admin.site.register(Tournament)
admin.site.register(Player)